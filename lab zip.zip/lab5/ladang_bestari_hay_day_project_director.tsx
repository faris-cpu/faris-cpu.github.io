import React, { useState, useEffect, useRef } from 'react';
import { 
  Tractor, Sprout, ShoppingBag, Users, Award, DollarSign, 
  TrendingUp, AlertTriangle, CheckCircle2, RefreshCw, Sparkles, 
  HeartHandshake, ChevronRight, Play, ShieldCheck, Sun, Info, Heart,
  Volume2, VolumeX, Truck, Home, Package, Store, Clock, Plus, Zap,
  ChevronUp, Lock, ArrowUpRight, Wrench, Smile, PieChart
} from 'lucide-react';

// Simple Audio Synthesizer for SFX without external audio files
const playSFX = (type, soundEnabled = true) => {
  if (!soundEnabled) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'harvest') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 0.15);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'plant') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(250, now);
      osc.frequency.exponentialRampToValueAtTime(150, now + 0.12);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
      osc.start(now);
      osc.stop(now + 0.12);
    } else if (type === 'coin') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(987.77, now); // B5
      osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'level') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.1);
      osc.frequency.setValueAtTime(783.99, now + 0.2);
      osc.frequency.setValueAtTime(1046.50, now + 0.3);
      gain.gain.setValueAtTime(0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
      osc.start(now);
      osc.stop(now + 0.5);
    } else if (type === 'craft') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(500, now + 0.2);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    }
  } catch (e) {
    // Audio context fallback silent fail
  }
};

export default function App() {
  // --- UTAMA STATE ---
  const [funds, setFunds] = useState(1200);
  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);
  const [morale, setMorale] = useState(85); // 0 - 100
  const [reputation, setReputation] = useState(60); // 0 - 100
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [activeTab, setActiveTab] = useState('farm'); // 'farm', 'animals', 'factory', 'orders', 'shop', 'director'

  // --- FLOATING TEXT ANIMATIONS ---
  const [floatingTexts, setFloatingTexts] = useState([]);

  const addFloatingText = (text, color = 'text-amber-300', x = 50, y = 50) => {
    const id = Date.now() + Math.random();
    setFloatingTexts(prev => [...prev, { id, text, color, x, y }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1200);
  };

  // --- NOTIFICATION TOAST ---
  const [toast, setToast] = useState(null);
  const showToast = (msg, type = 'info') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  // --- SILO (TANAMAN) & GUDANG (BARANG PROSES & TERNAKAN) ---
  const [siloCap, setSiloCap] = useState(50);
  const [barnCap, setBarnCap] = useState(50);

  const [silo, setSilo] = useState({
    padi: 8,
    jagung: 6,
    cili: 4,
    sayur: 5,
    tebu: 3
  });

  const [barn, setBarn] = useState({
    telur: 6,
    susuLembu: 4,
    susuKambing: 3,
    dedakAyam: 5,
    dedakLembu: 4,
    dedakKambing: 3,
    rotiJagung: 2,
    kejuFresh: 1,
    jusSayur: 2,
    gulaMelaka: 1
  });

  // Quantities calculation
  const totalSiloCount = Object.values(silo).reduce((a, b) => a + b, 0);
  const totalBarnCount = Object.values(barn).reduce((a, b) => a + b, 0);

  // --- CROP DEFINITIONS ---
  const CROPS = {
    padi: { name: 'Padi', growTime: 4, exp: 3, icon: '🌾', seedCost: 5, sellPrice: 8, reqLevel: 1 },
    jagung: { name: 'Jagung', growTime: 8, exp: 5, icon: '🌽', seedCost: 10, sellPrice: 16, reqLevel: 1 },
    sayur: { name: 'Sayur Segar', growTime: 12, exp: 7, icon: '🥬', seedCost: 15, sellPrice: 24, reqLevel: 2 },
    cili: { name: 'Cili Merah', growTime: 18, exp: 10, icon: '🌶️', seedCost: 20, sellPrice: 35, reqLevel: 3 },
    tebu: { name: 'Tebu Manis', growTime: 25, exp: 14, icon: '🎋', seedCost: 28, sellPrice: 50, reqLevel: 4 }
  };

  // --- FARM PLOTS (12 GRID TILES) ---
  const [plots, setPlots] = useState([
    { id: 1, crop: 'padi', stage: 2, timer: 0 },
    { id: 2, crop: 'padi', stage: 2, timer: 0 },
    { id: 3, crop: 'jagung', stage: 2, timer: 0 },
    { id: 4, crop: null, stage: 0, timer: 0 },
    { id: 5, crop: null, stage: 0, timer: 0 },
    { id: 6, crop: null, stage: 0, timer: 0 },
    { id: 7, crop: null, stage: 0, timer: 0, locked: false },
    { id: 8, crop: null, stage: 0, timer: 0, locked: false },
    { id: 9, crop: null, stage: 0, timer: 0, locked: true, reqLevel: 2, cost: 200 },
    { id: 10, crop: null, stage: 0, timer: 0, locked: true, reqLevel: 3, cost: 400 },
    { id: 11, crop: null, stage: 0, timer: 0, locked: true, reqLevel: 4, cost: 600 },
    { id: 12, crop: null, stage: 0, timer: 0, locked: true, reqLevel: 5, cost: 1000 },
  ]);

  const [selectedCropToPlant, setSelectedCropToPlant] = useState('padi');

  // --- ANIMAL PENS ---
  const [animals, setAnimals] = useState({
    ayam: { name: 'Reban Ayam', count: 4, icon: '🐓', product: 'telur', prodName: 'Telur Ayam', feedReq: 'dedakAyam', fedTimer: 0, isFed: false, ready: true, cycleTime: 10, exp: 5 },
    lembu: { name: 'Kandang Lembu', count: 2, icon: '🐄', product: 'susuLembu', prodName: 'Susu Lembu', feedReq: 'dedakLembu', fedTimer: 0, isFed: false, ready: true, cycleTime: 18, exp: 8 },
    kambing: { name: 'Kandang Kambing', count: 3, icon: '🐐', product: 'susuKambing', prodName: 'Susu Kambing', feedReq: 'dedakKambing', fedTimer: 0, isFed: false, ready: true, cycleTime: 22, exp: 12 }
  });

  // --- PROCESSING BUILDINGS & QUEUES ---
  const RECIPES = {
    // Kilang Makanan Ternakan
    dedakAyam: { name: 'Dedak Ayam', building: 'feedMill', time: 5, ingredients: { padi: 2 }, icon: '🌾' },
    dedakLembu: { name: 'Dedak Lembu', building: 'feedMill', time: 8, ingredients: { jagung: 2, sayur: 1 }, icon: '🌽' },
    dedakKambing: { name: 'Dedak Kambing', building: 'feedMill', time: 10, ingredients: { sayur: 2, tebu: 1 }, icon: '🥬' },
    // Kilang Roti & Artisan
    rotiJagung: { name: 'Roti Jagung Manis', building: 'bakery', time: 15, ingredients: { jagung: 3, telur: 2 }, icon: '🍞' },
    kejuFresh: { name: 'Keju Segar Halal', building: 'bakery', time: 20, ingredients: { susuLembu: 3 }, icon: '🧀' },
    jusSayur: { name: 'Jus Vigor Sayur-Cili', building: 'juicer', time: 14, ingredients: { sayur: 2, cili: 1 }, icon: '🧃' },
    gulaMelaka: { name: 'Sirap Tebu Asli', building: 'juicer', time: 16, ingredients: { tebu: 3 }, icon: '🍯' }
  };

  const [productionQueues, setProductionQueues] = useState({
    feedMill: [], // [{ recipeKey, timer, maxTime }]
    bakery: [],
    juicer: []
  });

  // --- MARKET ORDERS (LORI HANTAR & TRUCK) ---
  const [truckOrders, setTruckOrders] = useState([
    { id: 1, client: 'Pasar Tani Tempatan', items: { padi: 4, jagung: 3 }, rewardGold: 140, rewardXp: 25, completed: false },
    { id: 2, client: 'Kantin Sekolah Bestari', items: { telur: 4, rotiJagung: 1 }, rewardGold: 220, rewardXp: 40, completed: false },
    { id: 3, client: 'Restoran Organik Halal', items: { susuLembu: 3, kejuFresh: 1 }, rewardGold: 380, rewardXp: 60, completed: false },
    { id: 4, client: 'Kedai Jus Segar Komuniti', items: { jusSayur: 2, sayur: 4 }, rewardGold: 310, rewardXp: 50, completed: false }
  ]);

  const [truckState, setTruckState] = useState('idle'); // 'idle', 'delivering', 'returning'
  const [truckTimer, setTruckTimer] = useState(0);

  // --- ROADSIDE SHOP (KEDAI TEPI JALAN) ---
  const [roadsideSlots, setRoadsideSlots] = useState([
    { id: 1, item: null, amount: 0, price: 0, sold: false },
    { id: 2, item: null, amount: 0, price: 0, sold: false },
    { id: 3, item: null, amount: 0, price: 0, sold: false },
    { id: 4, item: null, amount: 0, price: 0, sold: false }
  ]);

  // --- WORKERS & STAFF MANAGEMENT (PENGARAH PROJEK) ---
  const [staff, setStaff] = useState([
    { id: 1, name: 'Pak Samad', role: 'Penyelia Plot Tanaman', bonus: '+15% Kematangan Tanam', salary: 120, hired: true },
    { id: 2, name: 'Mak Cik Siti', role: 'Pengurus Ternakan', bonus: '+20% Hasil Ternakan', salary: 150, hired: false },
    { id: 3, name: 'Ali Tech', role: 'Juruteknik Mesin', bonus: '-25% Masa Kilang', salary: 200, hired: false }
  ]);

  // --- DILEMMA KEPIMPINAN / LEADERSHIP EVENT ---
  const [activeDilemma, setActiveDilemma] = useState(null);

  const DILEMMAS = [
    {
      id: 1,
      title: 'Aduan Cuaca Panas Terik',
      desc: 'Pekerja mengadu keletihan melampau akibat cuaca panas terik. Mereka meminta waktu rehat tambahan dan minuman segar.',
      options: [
        {
          text: 'Sediakan Minuman & Rehat Ekstra (RM 150)',
          effect: () => {
            setFunds(f => f - 150);
            setMorale(m => Math.min(100, m + 15));
            setReputation(r => Math.min(100, r + 5));
            return 'Pekerja gembira & bertenaga! Moral staf meningkat tinggi.';
          }
        },
        {
          text: 'Teruskan Kerja Mengikut Jadual',
          effect: () => {
            setMorale(m => Math.max(0, m - 20));
            return 'Pekerja merungut dan kecewa. Moral staf merosot.';
          }
        }
      ]
    },
    {
      id: 2,
      title: 'Permintaan Produk Organik Halal',
      desc: 'Persatuan Pengguna ingin melawat ladang untuk memberikan Sijil Kecemerlangan Organik Halal.',
      options: [
        {
          text: 'Anjurkan Sesi Lawatan & Jamuan (RM 250)',
          effect: () => {
            setFunds(f => f - 250);
            setReputation(r => Math.min(100, r + 20));
            addXp(100);
            return 'Lawatan sangat berjaya! Reputasi ladang melonjak naik.';
          }
        },
        {
          text: 'Lawatan Ringkas Tanpa Jamuan',
          effect: () => {
            setReputation(r => Math.min(100, r + 5));
            return 'Lawatan berjalan biasa sahaja.';
          }
        }
      ]
    },
    {
      id: 3,
      title: 'Peningkatan Kos Benih & Bahan Rawak',
      desc: 'Pembekal utama menaikkan harga benih tanaman secara mengejut.',
      options: [
        {
          text: 'Beli Pukal Berdiskaun (RM 300)',
          effect: () => {
            setFunds(f => f - 300);
            setSilo(s => ({ ...s, padi: s.padi + 10, jagung: s.jagung + 10 }));
            return 'Berjaya mendapat stok pukal benih padi & jagung!';
          }
        },
        {
          text: 'Beli Mengikut Keperluan Sahaja',
          effect: () => {
            return 'Operasi diteruskan seperti biasa tanpa stok tambahan.';
          }
        }
      ]
    }
  ];

  // --- XP & LEVEL UP LOGIC ---
  const xpNeeded = level * 100;
  const addXp = (amount) => {
    setXp(prevXp => {
      const newXp = prevXp + amount;
      if (newXp >= level * 100) {
        setLevel(l => {
          const nextLevel = l + 1;
          showToast(`🎉 TAHNIAH! NAIK LEVEL ${nextLevel}! Unlock barang & plot baru!`, 'success');
          playSFX('level', soundEnabled);
          // Unlock plots naturally
          setPlots(pList => pList.map(p => p.reqLevel === nextLevel ? { ...p, locked: false } : p));
          return nextLevel;
        });
        return newXp - (level * 100);
      }
      return newXp;
    });
  };

  // --- GAME LOOP / TIMERS ---
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Crop Plots Growth
      setPlots(prevPlots => 
        prevPlots.map(plot => {
          if (plot.stage === 1) {
            if (plot.timer <= 1) {
              return { ...plot, stage: 2, timer: 0 };
            }
            return { ...plot, timer: plot.timer - 1 };
          }
          return plot;
        })
      );

      // 2. Animal Feeding Cycle
      setAnimals(prev => {
        const next = { ...prev };
        Object.keys(next).forEach(key => {
          if (next[key].isFed && !next[key].ready) {
            if (next[key].fedTimer <= 1) {
              next[key].isFed = false;
              next[key].ready = true;
              next[key].fedTimer = 0;
            } else {
              next[key].fedTimer -= 1;
            }
          }
        });
        return next;
      });

      // 3. Factory Production Queues
      setProductionQueues(prev => {
        const nextQueues = { ...prev };
        Object.keys(nextQueues).forEach(bKey => {
          if (nextQueues[bKey].length > 0) {
            const currentItem = nextQueues[bKey][0];
            if (currentItem.timer <= 1) {
              // Complete item
              const recipe = RECIPES[currentItem.recipeKey];
              setBarn(b => ({ ...b, [currentItem.recipeKey]: (b[currentItem.recipeKey] || 0) + 1 }));
              addXp(12);
              showToast(`🏭 Kilang siap memproses ${recipe.name}!`, 'success');
              playSFX('craft', soundEnabled);
              // Shift queue
              nextQueues[bKey] = nextQueues[bKey].slice(1);
            } else {
              nextQueues[bKey][0] = { ...currentItem, timer: currentItem.timer - 1 };
            }
          }
        });
        return nextQueues;
      });

      // 4. Truck Delivery Timer
      if (truckState === 'delivering') {
        setTruckTimer(t => {
          if (t <= 1) {
            setTruckState('returning');
            return 5; // returning time
          }
          return t - 1;
        });
      } else if (truckState === 'returning') {
        setTruckTimer(t => {
          if (t <= 1) {
            setTruckState('idle');
            return 0;
          }
          return t - 1;
        });
      }

      // 5. Roadside Shop Sales Automation (Buyers NPC)
      setRoadsideSlots(slots => 
        slots.map(slot => {
          if (slot.item && !slot.sold && Math.random() < 0.08) {
            showToast(`🛒 Pembeli telah membeli ${slot.amount}x ${slot.item} di Kedai Tepi Jalan!`, 'info');
            return { ...slot, sold: true };
          }
          return slot;
        })
      );

      // 6. Random Leadership Dilemma Trigger
      if (Math.random() < 0.015 && !activeDilemma) {
        const randomD = DILEMMAS[Math.floor(Math.random() * DILEMMAS.length)];
        setActiveDilemma(randomD);
      }

    }, 1000);

    return () => clearInterval(interval);
  }, [truckState, activeDilemma, soundEnabled]);

  // --- ACTIONS: TANAMAN ---
  const plantCrop = (plotId) => {
    const plot = plots.find(p => p.id === plotId);
    if (!plot || plot.locked || plot.stage !== 0) return;

    const cropInfo = CROPS[selectedCropToPlant];
    if (cropInfo.reqLevel > level) {
      showToast(`Memerlukan Level ${cropInfo.reqLevel} untuk menanam ${cropInfo.name}!`, 'error');
      return;
    }

    if (totalSiloCount >= siloCap) {
      showToast('Silo penuh! Tingkatkan kapasiti Silo dahulu.', 'error');
      return;
    }

    if (funds < cropInfo.seedCost) {
      showToast('Dana (RM) tidak mencukupi untuk benih!', 'error');
      return;
    }

    // Has worker speed bonus?
    const hasWorker = staff.find(s => s.id === 1 && s.hired);
    const speedBonus = hasWorker ? 0.85 : 1;
    const finalGrowTime = Math.max(2, Math.round(cropInfo.growTime * speedBonus));

    setFunds(f => f - cropInfo.seedCost);
    setPlots(plots.map(p => p.id === plotId ? { ...p, crop: selectedCropToPlant, stage: 1, timer: finalGrowTime } : p));
    playSFX('plant', soundEnabled);
    addFloatingText(`-${cropInfo.seedCost} RM`, 'text-rose-400');
  };

  const harvestCrop = (plotId, e) => {
    const plot = plots.find(p => p.id === plotId);
    if (!plot || plot.stage !== 2) return;

    if (totalSiloCount >= siloCap) {
      showToast('Silo simpanan anda telah penuh!', 'error');
      return;
    }

    const cropInfo = CROPS[plot.crop];
    const harvestYield = 2; // Each plot gives 2 crops

    setSilo(s => ({ ...s, [plot.crop]: (s[plot.crop] || 0) + harvestYield }));
    setPlots(plots.map(p => p.id === plotId ? { ...p, crop: null, stage: 0, timer: 0 } : p));
    addXp(cropInfo.exp);
    playSFX('harvest', soundEnabled);

    // Floating UI
    const rect = e?.currentTarget?.getBoundingClientRect();
    const x = rect ? rect.left + rect.width / 2 : window.innerWidth / 2;
    const y = rect ? rect.top : window.innerHeight / 2;
    addFloatingText(`+${harvestYield} ${cropInfo.name}`, 'text-emerald-400', x, y);
  };

  const unlockPlot = (plotId) => {
    const plot = plots.find(p => p.id === plotId);
    if (!plot || !plot.locked) return;

    if (level < plot.reqLevel) {
      showToast(`Capai Level ${plot.reqLevel} untuk buka plot ini!`, 'error');
      return;
    }
    if (funds < plot.cost) {
      showToast('Bajet (RM) tidak mencukupi!', 'error');
      return;
    }

    setFunds(f => f - plot.cost);
    setPlots(plots.map(p => p.id === plotId ? { ...p, locked: false } : p));
    showToast('Plot tanah baru berjaya dibeli!', 'success');
    playSFX('coin', soundEnabled);
  };

  // --- ACTIONS: ANIMAL FEEDING & HARVEST ---
  const feedAnimal = (animalKey) => {
    const anim = animals[animalKey];
    if (anim.isFed || !anim.ready) {
      showToast('Ternakan sedang mencerna makanan!', 'info');
      return;
    }

    const requiredFeed = anim.feedReq;
    if ((barn[requiredFeed] || 0) < 1) {
      showToast(`Anda memerlukan 1x ${requiredFeed} di Gudang! Process di Kilang Makanan.`, 'error');
      return;
    }

    // Deduct feed
    setBarn(b => ({ ...b, [requiredFeed]: b[requiredFeed] - 1 }));
    setAnimals(prev => ({
      ...prev,
      [animalKey]: { ...prev[animalKey], isFed: true, ready: false, fedTimer: anim.cycleTime }
    }));
    playSFX('plant', soundEnabled);
    showToast(`${anim.name} telah diberi makan!`, 'success');
  };

  const collectAnimalProduct = (animalKey, e) => {
    const anim = animals[animalKey];
    if (!anim.ready || anim.isFed) return;

    if (totalBarnCount >= barnCap) {
      showToast('Gudang simpanan penuh!', 'error');
      return;
    }

    const bonusStaff = staff.find(s => s.id === 2 && s.hired);
    const amountProduced = bonusStaff ? anim.count + 1 : anim.count;

    setBarn(b => ({ ...b, [anim.product]: (b[anim.product] || 0) + amountProduced }));
    setAnimals(prev => ({
      ...prev,
      [animalKey]: { ...prev[animalKey], ready: true, isFed: false }
    }));
    addXp(anim.exp);
    playSFX('harvest', soundEnabled);

    const rect = e?.currentTarget?.getBoundingClientRect();
    const x = rect ? rect.left + rect.width / 2 : window.innerWidth / 2;
    const y = rect ? rect.top : window.innerHeight / 2;
    addFloatingText(`+${amountProduced} ${anim.prodName}`, 'text-amber-400', x, y);
  };

  // --- ACTIONS: FACTORY QUEUE ---
  const addToFactoryQueue = (recipeKey) => {
    const recipe = RECIPES[recipeKey];
    if (!recipe) return;

    // Check ingredients
    for (const [ingKey, reqAmount] of Object.entries(recipe.ingredients)) {
      const availSilo = silo[ingKey] || 0;
      const availBarn = barn[ingKey] || 0;
      if (availSilo < reqAmount && availBarn < reqAmount) {
        showToast(`Bahan tidak cukup: Memerlukan ${reqAmount}x ${ingKey}!`, 'error');
        return;
      }
    }

    // Deduct ingredients from Silo or Barn
    for (const [ingKey, reqAmount] of Object.entries(recipe.ingredients)) {
      if ((silo[ingKey] || 0) >= reqAmount) {
        setSilo(s => ({ ...s, [ingKey]: s[ingKey] - reqAmount }));
      } else if ((barn[ingKey] || 0) >= reqAmount) {
        setBarn(b => ({ ...b, [ingKey]: b[ingKey] - reqAmount }));
      }
    }

    // Apply technician speed bonus
    const tech = staff.find(s => s.id === 3 && s.hired);
    const finalTime = tech ? Math.round(recipe.time * 0.75) : recipe.time;

    setProductionQueues(prev => ({
      ...prev,
      [recipe.building]: [...prev[recipe.building], { recipeKey, timer: finalTime, maxTime: finalTime }]
    }));

    playSFX('craft', soundEnabled);
    showToast(`Memulakan pemprosesan ${recipe.name}...`, 'info');
  };

  // --- ACTIONS: TRUCK ORDERS ---
  const sendTruckOrder = (orderId) => {
    if (truckState !== 'idle') {
      showToast('Lori hantar barang sedang dalam perjalanan!', 'info');
      return;
    }

    const order = truckOrders.find(o => o.id === orderId);
    if (!order) return;

    // Check all required items in Silo & Barn
    for (const [itemKey, reqQty] of Object.entries(order.items)) {
      const inSilo = silo[itemKey] || 0;
      const inBarn = barn[itemKey] || 0;
      if (inSilo < reqQty && inBarn < reqQty) {
        showToast(`Stok ${itemKey} tidak mencukupi untuk penghantaran!`, 'error');
        return;
      }
    }

    // Deduct items
    for (const [itemKey, reqQty] of Object.entries(order.items)) {
      if ((silo[itemKey] || 0) >= reqQty) {
        setSilo(s => ({ ...s, [itemKey]: s[itemKey] - reqQty }));
      } else {
        setBarn(b => ({ ...b, [itemKey]: b[itemKey] - reqQty }));
      }
    }

    // Start Truck delivery
    setTruckState('delivering');
    setTruckTimer(6); // 6 seconds delivery

    // Reward
    setFunds(f => f + order.rewardGold);
    addXp(order.rewardXp);
    setReputation(r => Math.min(100, r + 4));
    playSFX('coin', soundEnabled);

    // Refresh completed order
    setTruckOrders(orders => 
      orders.map(o => o.id === orderId ? { ...o, completed: true } : o)
    );

    showToast(`Lori bertolak membawa pesanan ke ${order.client}! (+RM${order.rewardGold})`, 'success');
  };

  const refreshTruckOrder = (orderId) => {
    const clients = ['Koperasi Kampung', 'Hotel Premier Halal', 'Supermarket Bestari', 'Restoran Seri Melayu'];
    const possibleItems = ['padi', 'jagung', 'sayur', 'telur', 'susuLembu', 'rotiJagung', 'jusSayur'];
    
    const randomClient = clients[Math.floor(Math.random() * clients.length)];
    const item1 = possibleItems[Math.floor(Math.random() * possibleItems.length)];
    const item2 = possibleItems[Math.floor(Math.random() * possibleItems.length)];
    
    const newItems = { [item1]: Math.floor(Math.random() * 3) + 2 };
    if (item1 !== item2) newItems[item2] = Math.floor(Math.random() * 2) + 1;

    const rewardGold = Math.floor(Math.random() * 200) + 150;
    const rewardXp = Math.floor(Math.random() * 30) + 20;

    setTruckOrders(orders => 
      orders.map(o => o.id === orderId ? {
        id: orderId,
        client: randomClient,
        items: newItems,
        rewardGold,
        rewardXp,
        completed: false
      } : o)
    );
    showToast('Pesanan baru telah dikemaskini di papan lori!', 'info');
  };

  // --- ACTIONS: ROADSIDE SHOP ---
  const putItemOnSale = (slotId, itemKey, amount, price) => {
    const availSilo = silo[itemKey] || 0;
    const availBarn = barn[itemKey] || 0;

    if (availSilo < amount && availBarn < amount) {
      showToast('Stok dalam Simpanan tidak mencukupi!', 'error');
      return;
    }

    if (availSilo >= amount) {
      setSilo(s => ({ ...s, [itemKey]: s[itemKey] - amount }));
    } else {
      setBarn(b => ({ ...b, [itemKey]: b[itemKey] - amount }));
    }

    setRoadsideSlots(slots => 
      slots.map(s => s.id === slotId ? { ...s, item: itemKey, amount, price, sold: false } : s)
    );

    showToast(`Barang dimasukkan ke Kedai Tepi Jalan!`, 'success');
  };

  const collectSaleMoney = (slotId) => {
    const slot = roadsideSlots.find(s => s.id === slotId);
    if (!slot || !slot.sold) return;

    setFunds(f => f + slot.price);
    addXp(15);
    playSFX('coin', soundEnabled);
    addFloatingText(`+RM ${slot.price}`, 'text-emerald-400');

    setRoadsideSlots(slots => 
      slots.map(s => s.id === slotId ? { ...s, item: null, amount: 0, price: 0, sold: false } : s)
    );
  };

  // --- ACTIONS: STAFF HIRE & DILEMMA ---
  const toggleHireStaff = (staffId) => {
    const member = staff.find(s => s.id === staffId);
    if (!member) return;

    if (!member.hired) {
      if (funds < member.salary) {
        showToast('Bajet tidak mencukupi untuk mengambil pekerja ini!', 'error');
        return;
      }
      setFunds(f => f - member.salary);
      setMorale(m => Math.min(100, m + 10));
      showToast(`Mengambil ${member.name} bekerja! Bonus diaktifkan.`, 'success');
    } else {
      showToast(`${member.name} telah dilepaskan dari tugas.`, 'info');
    }

    setStaff(prev => 
      prev.map(s => s.id === staffId ? { ...s, hired: !s.hired } : s)
    );
  };

  const handleDilemmaChoice = (opt) => {
    const msg = opt.effect();
    setActiveDilemma(null);
    showToast(msg, 'info');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col select-none relative overflow-x-hidden">
      
      {/* FLOATING TEXT OVERLAYS */}
      {floatingTexts.map(t => (
        <div
          key={t.id}
          style={{ left: `${t.x}px`, top: `${t.y - 20}px` }}
          className={`fixed z-50 pointer-events-none font-extrabold text-sm sm:text-base animate-bounce ${t.color} drop-shadow-md`}
        >
          {t.text}
        </div>
      ))}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border transition-all animate-in fade-in slide-in-from-top-2 ${
          toast.type === 'error' ? 'bg-rose-900/90 border-rose-500 text-rose-100' :
          toast.type === 'success' ? 'bg-emerald-900/90 border-emerald-500 text-emerald-100' :
          'bg-sky-900/90 border-sky-500 text-sky-100'
        }`}>
          <Info className="w-5 h-5 shrink-0" />
          <span className="text-xs sm:text-sm font-semibold">{toast.msg}</span>
        </div>
      )}

      {/* MODAL KEPUTUSAN KEPIMPINAN / DILEMMA */}
      {activeDilemma && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/60 max-w-lg w-full rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="bg-gradient-to-r from-amber-600/30 via-orange-600/20 to-transparent p-5 border-b border-slate-800 flex items-center gap-3">
              <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/40">
                <AlertTriangle className="w-7 h-7 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-extrabold tracking-widest text-amber-400">Keputusan Pengarah Projek</span>
                <h3 className="text-lg font-bold text-slate-100">{activeDilemma.title}</h3>
              </div>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                {activeDilemma.desc}
              </p>

              <div className="space-y-3 pt-2">
                {activeDilemma.options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleDilemmaChoice(opt)}
                    className="w-full text-left p-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/50 transition flex items-center justify-between group active:scale-98"
                  >
                    <span className="text-xs sm:text-sm font-semibold text-slate-200 group-hover:text-amber-400">
                      {opt.text}
                    </span>
                    <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-amber-400 group-hover:translate-x-1 transition" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* HEADER BAR (HAY DAY DASHBOARD STYLED) */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 sticky top-0 z-40 px-3 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          
          {/* LOGO & LEVEL */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 border border-emerald-400/30">
                <Tractor className="w-6 h-6 text-slate-950" />
              </div>
              {/* Level Badge */}
              <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
                {level}
              </div>
            </div>

            <div>
              <h1 className="font-extrabold text-sm sm:text-base leading-tight flex items-center gap-2">
                Ladang Bestari
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                  100% Halal
                </span>
              </h1>
              {/* XP Bar */}
              <div className="flex items-center gap-2 mt-0.5">
                <div className="w-24 sm:w-32 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
                  <div 
                    className="bg-gradient-to-r from-sky-400 to-indigo-500 h-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (xp / xpNeeded) * 100)}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-400 font-semibold">{xp}/{xpNeeded} XP</span>
              </div>
            </div>
          </div>

          {/* GAME RESOURCES (BAJET, MORAL, REPUTASI, STORAGE) */}
          <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto py-1">
            
            {/* BAJET (RM) */}
            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-2xl flex items-center gap-2 shrink-0">
              <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-xl">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Bajet</div>
                <div className="text-xs sm:text-sm font-extrabold text-emerald-400">RM {funds.toLocaleString()}</div>
              </div>
            </div>

            {/* MORAL WORKERS */}
            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-2xl flex items-center gap-2 shrink-0">
              <div className="p-1.5 bg-rose-500/20 text-rose-400 rounded-xl">
                <Smile className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Moral Staf</div>
                <div className="text-xs sm:text-sm font-extrabold text-rose-400">{morale}%</div>
              </div>
            </div>

            {/* REPUTASI */}
            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-2xl flex items-center gap-2 shrink-0">
              <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-xl">
                <Award className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Reputasi</div>
                <div className="text-xs sm:text-sm font-extrabold text-amber-400">{reputation}%</div>
              </div>
            </div>

            {/* SILO CAPACITY */}
            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-2xl flex items-center gap-2 shrink-0">
              <div className="p-1.5 bg-sky-500/20 text-sky-400 rounded-xl">
                <Package className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Silo</div>
                <div className="text-xs sm:text-sm font-extrabold text-sky-400">{totalSiloCount}/{siloCap}</div>
              </div>
            </div>

            {/* SOUND TOGGLE */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl border border-slate-700 transition"
              title="Tetapan Bunyi SFX"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
            </button>

          </div>

        </div>
      </header>

      {/* NAVIGATION TABS */}
      <nav className="bg-slate-900/60 border-b border-slate-800/80 px-4">
        <div className="max-w-7xl mx-auto flex items-center gap-2 overflow-x-auto py-2">
          {[
            { id: 'farm', label: 'Plot Tanaman', icon: Sprout },
            { id: 'animals', label: 'Ternakan Halal', icon: HeartHandshake },
            { id: 'factory', label: 'Kilang & Pemprosesan', icon: Wrench },
            { id: 'orders', label: 'Lori & Pesanan', icon: Truck },
            { id: 'shop', label: 'Kedai Tepi Jalan', icon: Store },
            { id: 'director', label: 'Pengarah Projek', icon: Users },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </nav>

      {/* MAIN GAME CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-4 gap-6">

        {/* INVENTORY SIDEBAR (RIGHT ON DESKTOP, BOTTOM ON MOBILE) */}
        <div className="lg:col-span-1 space-y-4 order-last lg:order-none">
          
          {/* SILO SIMPANAN TANAMAN */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Sprout className="w-4 h-4 text-emerald-400" />
                Silo (Tanaman Raw)
              </h3>
              <span className="text-xs font-bold text-sky-400">{totalSiloCount}/{siloCap}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              {Object.entries(CROPS).map(([key, crop]) => (
                <div key={key} className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800/80 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 font-medium">{crop.icon} {crop.name}</span>
                  <span className="font-extrabold text-emerald-400">{silo[key] || 0}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                if (funds >= 250) {
                  setFunds(f => f - 250);
                  setSiloCap(c => c + 25);
                  showToast('Silo dinaik taraf (+25 Kapasiti)!', 'success');
                  playSFX('coin', soundEnabled);
                } else {
                  showToast('Bajet tidak mencukupi (RM 250)!', 'error');
                }
              }}
              className="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" /> Naiktaraf Silo (RM 250)
            </button>
          </div>

          {/* GUDANG BARANG PROSES & TERNAKAN */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Package className="w-4 h-4 text-amber-400" />
                Gudang (Hasil & Artisan)
              </h3>
              <span className="text-xs font-bold text-amber-400">{totalBarnCount}/{barnCap}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span>🥚 Telur</span>
                <span className="font-extrabold text-amber-400">{barn.telur || 0}</span>
              </div>
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span>🥛 Susu Lembu</span>
                <span className="font-extrabold text-amber-400">{barn.susuLembu || 0}</span>
              </div>
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span>🐐 Susu Kambing</span>
                <span className="font-extrabold text-amber-400">{barn.susuKambing || 0}</span>
              </div>
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span>🍞 Roti Jagung</span>
                <span className="font-extrabold text-amber-400">{barn.rotiJagung || 0}</span>
              </div>
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span>🧀 Keju Segar</span>
                <span className="font-extrabold text-amber-400">{barn.kejuFresh || 0}</span>
              </div>
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span>🧃 Jus Sayur</span>
                <span className="font-extrabold text-amber-400">{barn.jusSayur || 0}</span>
              </div>
            </div>

            <button
              onClick={() => {
                if (funds >= 300) {
                  setFunds(f => f - 300);
                  setBarnCap(c => c + 25);
                  showToast('Gudang dinaik taraf (+25 Kapasiti)!', 'success');
                  playSFX('coin', soundEnabled);
                } else {
                  showToast('Bajet tidak mencukupi (RM 300)!', 'error');
                }
              }}
              className="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" /> Naiktaraf Gudang (RM 300)
            </button>
          </div>

        </div>

        {/* CENTRAL DISPLAY AREA */}
        <div className="lg:col-span-3 space-y-6">

          {/* TAB 1: FARM PLOTS (PLOT TANAMAN ISOMETRIC GRID) */}
          {activeTab === 'farm' && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-5">
              
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-100 flex items-center gap-2">
                    <Sprout className="w-5 h-5 text-emerald-400" />
                    Plot Tanaman Pertanian
                  </h2>
                  <p className="text-xs text-slate-400">Pilih benih di bawah, kemudian tekan plot tanah untuk menanam.</p>
                </div>

                {/* SEED SELECTION SELECTOR */}
                <div className="flex items-center gap-2 overflow-x-auto py-1 max-w-full">
                  {Object.entries(CROPS).map(([key, crop]) => {
                    const isSelected = selectedCropToPlant === key;
                    const isLocked = crop.reqLevel > level;
                    return (
                      <button
                        key={key}
                        onClick={() => setSelectedCropToPlant(key)}
                        disabled={isLocked}
                        className={`px-3 py-2 rounded-2xl text-xs font-bold border transition flex items-center gap-1.5 shrink-0 ${
                          isLocked 
                            ? 'bg-slate-950 text-slate-600 border-slate-800 cursor-not-allowed'
                            : isSelected 
                            ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/20 scale-105' 
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        <span>{crop.icon}</span>
                        <span>{crop.name}</span>
                        {isLocked ? (
                          <Lock className="w-3 h-3 text-slate-500" />
                        ) : (
                          <span className="text-[10px] opacity-80">RM{crop.seedCost}</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* FARM GRID TILES (3x4 GRID) */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
                {plots.map(plot => (
                  <div
                    key={plot.id}
                    onClick={(e) => {
                      if (plot.locked) unlockPlot(plot.id);
                      else if (plot.stage === 0) plantCrop(plot.id);
                      else if (plot.stage === 2) harvestCrop(plot.id, e);
                    }}
                    className={`relative rounded-3xl p-4 min-h-[140px] flex flex-col justify-between cursor-pointer transition-all duration-200 border-2 ${
                      plot.locked
                        ? 'bg-slate-950/90 border-dashed border-slate-800 hover:border-slate-700'
                        : plot.stage === 2
                        ? 'bg-gradient-to-b from-amber-900/40 to-emerald-950 border-emerald-500/80 shadow-lg shadow-emerald-500/10 hover:scale-102'
                        : plot.stage === 1
                        ? 'bg-slate-900 border-amber-500/40'
                        : 'bg-slate-950 hover:bg-slate-900 border-slate-800 hover:border-emerald-500/50'
                    }`}
                  >
                    {/* Plot Status Header */}
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-extrabold text-slate-500">PLOT #{plot.id}</span>
                      {plot.stage === 1 && (
                        <span className="text-[10px] bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/30 flex items-center gap-1 font-bold">
                          <RefreshCw className="w-3 h-3 animate-spin" /> {plot.timer}s
                        </span>
                      )}
                      {plot.stage === 2 && (
                        <span className="text-[10px] bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full font-black animate-pulse">
                          TUAI!
                        </span>
                      )}
                    </div>

                    {/* Plot Visual Element */}
                    <div className="my-2 text-center">
                      {plot.locked ? (
                        <div className="space-y-1">
                          <Lock className="w-6 h-6 text-slate-600 mx-auto" />
                          <div className="text-[11px] font-bold text-slate-400">Buka Plot</div>
                          <div className="text-[10px] text-amber-400 font-extrabold">Lvl {plot.reqLevel} • RM{plot.cost}</div>
                        </div>
                      ) : plot.stage === 0 ? (
                        <div className="space-y-1">
                          <div className="text-2xl opacity-40">🟫</div>
                          <div className="text-[11px] font-semibold text-slate-400">Tekan Untuk Tanam</div>
                        </div>
                      ) : plot.stage === 1 ? (
                        <div className="space-y-1">
                          <div className="text-3xl animate-bounce">🌱</div>
                          <div className="text-[11px] text-slate-300 font-bold capitalize">{CROPS[plot.crop]?.name}</div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <div className="text-4xl animate-bounce">{CROPS[plot.crop]?.icon}</div>
                          <div className="text-[11px] text-emerald-400 font-extrabold capitalize">{CROPS[plot.crop]?.name} Matang</div>
                        </div>
                      )}
                    </div>

                    {/* Footer helper */}
                    {!plot.locked && plot.stage === 0 && (
                      <div className="text-[10px] text-center text-emerald-400 font-bold bg-emerald-500/10 py-1 rounded-xl border border-emerald-500/20">
                        {CROPS[selectedCropToPlant]?.icon} {CROPS[selectedCropToPlant]?.name}
                      </div>
                    )}
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* TAB 2: ANIMALS (REBAN & KANDANG TERNAKAN HALAL) */}
          {activeTab === 'animals' && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-5">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-100 flex items-center gap-2">
                  <HeartHandshake className="w-5 h-5 text-amber-400" />
                  Kawasan Ternakan Halal
                </h2>
                <p className="text-xs text-slate-400">Beri dedak pemakanan berkualiti tinggi untuk mengumpul hasil ternakan.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(animals).map(([key, anim]) => (
                  <div key={key} className="bg-slate-950 border border-slate-800 rounded-3xl p-4 flex flex-col justify-between space-y-4 shadow-lg">
                    
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-3xl">{anim.icon}</span>
                        <div>
                          <h4 className="font-extrabold text-sm text-slate-200">{anim.name}</h4>
                          <span className="text-[10px] text-slate-400">{anim.count} Ekor Ternakan</span>
                        </div>
                      </div>
                    </div>

                    {/* Status Makanan */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400">Status Pencernaan:</span>
                        <span className="font-bold text-amber-400">
                          {anim.isFed ? `Masa Siap: ${anim.fedTimer}s` : anim.ready ? 'Sedia Dikutip' : 'Lapar'}
                        </span>
                      </div>
                      
                      <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
                        <div 
                          className="bg-amber-400 h-full transition-all duration-300"
                          style={{ 
                            width: anim.isFed 
                              ? `${((anim.cycleTime - anim.fedTimer) / anim.cycleTime) * 100}%` 
                              : anim.ready ? '100%' : '0%' 
                          }}
                        />
                      </div>
                    </div>

                    {/* Buttons */}
                    <div className="space-y-2 pt-2 border-t border-slate-800">
                      <button
                        onClick={() => feedAnimal(key)}
                        disabled={anim.isFed || anim.ready}
                        className={`w-full py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                          anim.isFed || anim.ready
                            ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                            : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30'
                        }`}
                      >
                        🌾 Beri {RECIPES[anim.feedReq]?.name} (Stok: {barn[anim.feedReq] || 0})
                      </button>

                      <button
                        onClick={(e) => collectAnimalProduct(key, e)}
                        disabled={!anim.ready || anim.isFed}
                        className={`w-full py-2.5 rounded-2xl text-xs font-extrabold transition shadow-md ${
                          anim.ready && !anim.isFed
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 scale-102'
                            : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        {anim.ready && !anim.isFed ? `Kumpul ${anim.prodName} ✨` : 'Belum Sedia'}
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: FACTORY (KILANG PEMPROSESAN & ARTISAN) */}
          {activeTab === 'factory' && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-6">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-100 flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-sky-400" />
                  Kilang & Pemprosesan Artisan
                </h2>
                <p className="text-xs text-slate-400">Tukarkan hasil tanaman raw kepada produk siap bernilai tinggi.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {[
                  { key: 'feedMill', name: 'Kilang Makanan Ternakan', recipes: ['dedakAyam', 'dedakLembu', 'dedakKambing'] },
                  { key: 'bakery', name: 'Kilang Roti & Keju', recipes: ['rotiJagung', 'kejuFresh'] },
                  { key: 'juicer', name: 'Kilang Jus & Sirap', recipes: ['jusSayur', 'gulaMelaka'] }
                ].map(building => (
                  <div key={building.key} className="bg-slate-950 border border-slate-800 rounded-3xl p-4 flex flex-col justify-between space-y-4">
                    
                    <div>
                      <h4 className="font-extrabold text-sm text-sky-400 border-b border-slate-800 pb-2 mb-3">
                        {building.name}
                      </h4>

                      {/* Queue Visual */}
                      <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800 mb-3 space-y-2">
                        <div className="text-[10px] font-bold text-slate-400 flex justify-between">
                          <span>Barisan Pemprosesan:</span>
                          <span>{productionQueues[building.key].length} Item</span>
                        </div>

                        {productionQueues[building.key].length === 0 ? (
                          <div className="text-[11px] text-slate-600 text-center py-2">Mesin Rehat</div>
                        ) : (
                          <div className="space-y-1.5">
                            {productionQueues[building.key].map((qItem, idx) => {
                              const r = RECIPES[qItem.recipeKey];
                              return (
                                <div key={idx} className="flex items-center justify-between bg-slate-950 p-2 rounded-xl text-xs border border-slate-800">
                                  <span className="font-bold text-slate-200">{r.icon} {r.name}</span>
                                  <span className="text-[10px] text-amber-400 font-extrabold">{qItem.timer}s</span>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* Recipe Buttons */}
                      <div className="space-y-2">
                        {building.recipes.map(rKey => {
                          const recipe = RECIPES[rKey];
                          return (
                            <button
                              key={rKey}
                              onClick={() => addToFactoryQueue(rKey)}
                              className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-sky-500/40 p-2.5 rounded-2xl text-left transition flex items-center justify-between group"
                            >
                              <div>
                                <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">{recipe.icon} {recipe.name}</div>
                                <div className="text-[9px] text-slate-400">
                                  {Object.entries(recipe.ingredients).map(([k, v]) => `${v}x ${k}`).join(', ')}
                                </div>
                              </div>
                              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-1 rounded-xl border border-slate-700">
                                {recipe.time}s
                              </span>
                            </button>
                          );
                        })}
                      </div>

                    </div>

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: ORDERS (LORI HANTAR & MARKET BOARD) */}
          {activeTab === 'orders' && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-6">
              
              {/* TRUCK STATUS ANIMATION BOARD */}
              <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800 p-5 rounded-3xl flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className={`p-4 rounded-2xl border ${
                    truckState === 'delivering' ? 'bg-amber-500/20 border-amber-500/40 text-amber-400 animate-bounce' :
                    truckState === 'returning' ? 'bg-sky-500/20 border-sky-500/40 text-sky-400' :
                    'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                  }`}>
                    <Truck className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base text-slate-100">Lori Penghantaran Barang</h3>
                    <p className="text-xs text-slate-400">
                      {truckState === 'delivering' ? `Lori sedang menghantar pesanan... (${truckTimer}s)` :
                       truckState === 'returning' ? `Lori dalam perjalanan pulang... (${truckTimer}s)` :
                       'Lori sedia di tapak pemuatan!'}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1.5 rounded-full border border-amber-500/20">
                    Status: {truckState.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* ORDERS LIST */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {truckOrders.map(order => (
                  <div key={order.id} className="bg-slate-950 border border-slate-800 rounded-3xl p-4 flex flex-col justify-between space-y-4">
                    
                    <div>
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                        <span className="font-bold text-sm text-slate-200">{order.client}</span>
                        {order.completed && (
                          <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1 font-bold">
                            <CheckCircle2 className="w-3 h-3" /> Selesai
                          </span>
                        )}
                      </div>

                      {/* Required Items */}
                      <div className="space-y-1.5 mb-3">
                        <div className="text-[10px] font-bold text-slate-400">Keperluan Barang:</div>
                        <div className="grid grid-cols-2 gap-1.5">
                          {Object.entries(order.items).map(([itemKey, reqQty]) => {
                            const availSilo = silo[itemKey] || 0;
                            const availBarn = barn[itemKey] || 0;
                            const totalAvail = availSilo + availBarn;
                            const hasEnough = totalAvail >= reqQty;
                            return (
                              <div key={itemKey} className={`p-2 rounded-xl text-xs flex justify-between items-center border ${
                                hasEnough ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-rose-950/40 border-rose-900/60 text-rose-300'
                              }`}>
                                <span className="capitalize font-semibold">{itemKey}</span>
                                <span className="font-extrabold">{totalAvail}/{reqQty}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Rewards & Actions */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                      <div>
                        <div className="text-xs font-extrabold text-emerald-400">+RM {order.rewardGold}</div>
                        <div className="text-[10px] text-sky-400 font-bold">+{order.rewardXp} XP</div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => refreshTruckOrder(order.id)}
                          className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-slate-400 hover:text-slate-200 transition"
                          title="Tukar Pesanan Baru"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => sendTruckOrder(order.id)}
                          disabled={order.completed || truckState !== 'idle'}
                          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition shadow-md ${
                            order.completed || truckState !== 'idle'
                              ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 scale-102'
                          }`}
                        >
                          Hantar Lori
                        </button>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: ROADSIDE SHOP (KEDAI TEPI JALAN) */}
          {activeTab === 'shop' && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-6">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-100 flex items-center gap-2">
                  <Store className="w-5 h-5 text-amber-400" />
                  Kedai Tepi Jalan (Roadside Shop)
                </h2>
                <p className="text-xs text-slate-400">Jual terus lebihan stok barangan anda kepada pembeli tempatan.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                {roadsideSlots.map(slot => (
                  <div key={slot.id} className="bg-slate-950 border border-slate-800 rounded-3xl p-4 flex flex-col justify-between min-h-[160px] text-center">
                    
                    <div className="text-[10px] font-bold text-slate-500">PETAK #{slot.id}</div>

                    {!slot.item ? (
                      <div className="space-y-2 my-2">
                        <div className="text-2xl opacity-30">📦</div>
                        <button
                          onClick={() => {
                            // Quick sell padi default
                            putItemOnSale(slot.id, 'padi', 3, 40);
                          }}
                          className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 py-1.5 rounded-xl text-xs font-bold transition"
                        >
                          + Letak Barang (3x Padi - RM40)
                        </button>
                      </div>
                    ) : slot.sold ? (
                      <div className="space-y-2 my-2">
                        <div className="text-3xl animate-bounce">💰</div>
                        <div className="text-xs font-extrabold text-emerald-400">Terjual! (+RM{slot.price})</div>
                        <button
                          onClick={() => collectSaleMoney(slot.id)}
                          className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 py-1.5 rounded-xl text-xs font-black transition"
                        >
                          Ambil Hasil Tunai
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2 my-2">
                        <div className="text-3xl">🛍️</div>
                        <div className="text-xs font-bold text-slate-200 capitalize">{slot.amount}x {slot.item}</div>
                        <div className="text-xs font-extrabold text-amber-400">Harga: RM{slot.price}</div>
                        <div className="text-[10px] text-slate-500">Menunggu Pembeli...</div>
                      </div>
                    )}

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: PROJECT DIRECTOR / LEADERSHIP ROOM */}
          {activeTab === 'director' && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-6">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-100 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-400" />
                  Bilik Pengarah Projek & Kebajikan Staf
                </h2>
                <p className="text-xs text-slate-400">Uruskan pengagihan pekerja dan buat keputusan strategic ladang.</p>
              </div>

              {/* STAFF LIST */}
              <div className="space-y-3">
                <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider">Senarai Pekerja & Juruteknik</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {staff.map(member => (
                    <div key={member.id} className="bg-slate-950 border border-slate-800 rounded-3xl p-4 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-extrabold text-sm text-slate-200">{member.name}</h4>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                            member.hired ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-900 text-slate-500 border-slate-800'
                          }`}>
                            {member.hired ? 'Bekerja' : 'Rehat'}
                          </span>
                        </div>
                        <div className="text-xs text-indigo-400 font-semibold">{member.role}</div>
                        <div className="text-[11px] text-emerald-400 font-bold mt-2 bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
                          {member.bonus}
                        </div>
                      </div>

                      <button
                        onClick={() => toggleHireStaff(member.id)}
                        className={`w-full py-2 rounded-2xl text-xs font-bold transition ${
                          member.hired 
                            ? 'bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800' 
                            : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black'
                        }`}
                      >
                        {member.hired ? 'Lepaskan Pekerja' : `Ambil Bekerja (RM ${member.salary})`}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* SIMULATE LEADERSHIP DILEMMA */}
              <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 text-center space-y-3">
                <h4 className="font-extrabold text-sm text-slate-200">Uji Kemahiran Kepimpinan Anda</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Cetuskan acara keputusan secara spontan untuk menangani dilema ladang, kebajikan staf, atau isu integriti halal.
                </p>
                <button
                  onClick={() => {
                    const randomD = DILEMMAS[Math.floor(Math.random() * DILEMMAS.length)];
                    setActiveDilemma(randomD);
                  }}
                  className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-black px-6 py-2.5 rounded-2xl text-xs transition shadow-lg shadow-indigo-500/20 inline-flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" /> Cetuskan Dilema Kepimpinan
                </button>
              </div>

            </div>
          )}

        </div>
      </main>

      {/* FOOTER BAR */}
      <footer className="bg-slate-900/80 border-t border-slate-800 py-3 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>&copy; Simulator Ladang Bestari - Mod Kepimpinan & Hay Day Flow</span>
          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <ShieldCheck className="w-4 h-4" /> Terjamin 100% Ternakan & Hasil Halal
          </span>
        </div>
      </footer>

    </div>
  );
}